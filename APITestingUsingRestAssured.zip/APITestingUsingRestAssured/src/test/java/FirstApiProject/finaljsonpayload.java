package FirstApiProject;

public class finaljsonpayload {


    private  proxyWrapper proxyWrapper;
    public proxyWrapper getproxyWrapper() {
        return proxyWrapper;
    }
    public void setproxyWrapper(proxyWrapper proxyWrapper) {
        this.proxyWrapper = proxyWrapper;
    }
}
